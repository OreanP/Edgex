"""Tests d'intégration sans réseau : si ça passe, les pièces s'emboîtent."""

from pathlib import Path

import pytest

from edgex import cache
from edgex.fakes import FixtureMarketSource, SimpleBroker, fake_agent
from edgex.replay import load_run, save_run
from edgex.schemas import RunResult


def test_fixtures_respect_the_contract():
    src = FixtureMarketSource()
    markets = src.list_markets()
    assert markets
    for m in markets:
        assert src.get_quote(m.id).market_id == m.id


def test_end_to_end_with_fakes():
    src = FixtureMarketSource()
    broker = SimpleBroker(cash_usd=1000)
    seen = []
    result = fake_agent("demo-tech-001", src, broker, on_step=seen.append)
    assert isinstance(result, RunResult)
    assert seen == result.steps  # l'interface reçoit exactement la trace
    assert result.decision == "BUY_YES"
    assert result.trade.amount_usd <= result.risk.max_amount_usd
    assert broker.get_portfolio().cash_usd == pytest.approx(1000 - result.trade.amount_usd)


def test_wide_spread_market_ends_in_skip():
    src = FixtureMarketSource()
    result = fake_agent("demo-crypto-003", src, SimpleBroker())
    assert result.decision == "SKIP" and result.trade is None


def test_replay_roundtrip(tmp_path: Path):
    src = FixtureMarketSource()
    result = fake_agent("demo-tech-001", src, SimpleBroker())
    path = save_run(result, tmp_path / "run.json")
    assert load_run(path) == result


def test_cache_offline_mode(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("EDGEX_CACHE_DIR", str(tmp_path))
    monkeypatch.setenv("EDGEX_MODE", "offline")
    url = "https://example.invalid/markets"
    with pytest.raises(RuntimeError):
        cache.get_json(url)
    cache._path_for(url, None).write_text('{"ok": true}', encoding="utf-8")
    assert cache.get_json(url) == {"ok": True}
