"""Tests du moteur de risque : ils fixent son comportement pour toute l'équipe."""

import pytest

from edgex import risk
from edgex.schemas import Forecast, OrderRequest, Portfolio, Position, Quote

QUOTE = Quote(market_id="m1", yes_bid=0.41, yes_ask=0.43)
CASH_1000 = Portfolio(cash_usd=1000.0)


def forecast(p: float, confidence: str = "medium") -> Forecast:
    return Forecast(probability=p, confidence=confidence)


def test_low_confidence_is_refused():
    d = risk.max_position("YES", forecast(0.90, "low"), QUOTE, CASH_1000)
    assert not d.approved and d.max_amount_usd == 0


def test_small_edge_is_refused():
    d = risk.max_position("YES", forecast(0.47), QUOTE, CASH_1000)  # edge 0.04 < 0.08
    assert not d.approved


def test_edge_is_measured_against_ask_not_mid():
    # milieu = 0.42 : edge « affiché » 0.08 ; mais on achète à 0.43 → edge réel 0.07 → refus
    d = risk.max_position("YES", forecast(0.50), QUOTE, CASH_1000)
    assert not d.approved
    assert d.edge == pytest.approx(0.07)


def test_kelly_sizing_medium_confidence():
    # Kelly = 0.14 / 0.57 ≈ 24.6 % ; × 1/4 × 0.5 × 1000 $ ≈ 30.70 $ (< plafond de 50 $)
    d = risk.max_position("YES", forecast(0.57), QUOTE, CASH_1000)
    assert d.approved
    assert d.max_amount_usd == pytest.approx(30.70, abs=0.01)


def test_position_cap_applies():
    # Kelly = 0.37 / 0.57 ≈ 64.9 % ; × 1/4 × 1000 $ ≈ 162 $ → plafonné à 5 % = 50 $
    d = risk.max_position("YES", forecast(0.80, "high"), QUOTE, CASH_1000)
    assert d.max_amount_usd == pytest.approx(50.0)


def test_order_above_max_is_refused_but_max_is_returned():
    order = OrderRequest(market_id="m1", side="YES", amount_usd=120)
    d = risk.check(order, forecast(0.57), QUOTE, CASH_1000)
    assert not d.approved
    assert d.max_amount_usd == pytest.approx(30.70, abs=0.01)


def test_order_within_max_is_accepted():
    order = OrderRequest(market_id="m1", side="YES", amount_usd=30.0)
    assert risk.check(order, forecast(0.57), QUOTE, CASH_1000).approved


def test_no_side_uses_no_price():
    # P(NON) = 0.75 ; prix du NON ≈ 1 - 0.41 = 0.59 → edge 0.16
    d = risk.max_position("NO", forecast(0.25), QUOTE, CASH_1000)
    assert d.approved
    assert d.edge == pytest.approx(0.16)
    assert d.price == pytest.approx(0.59)


def test_wide_spread_is_refused():
    wide = Quote(market_id="m1", yes_bid=0.30, yes_ask=0.45)
    assert not risk.max_position("YES", forecast(0.70), wide, CASH_1000).approved


def test_total_exposure_cap():
    # capital 1000 $, déjà 300 $ engagés = plafond de 30 % atteint → plus de marge
    busy = Portfolio(cash_usd=700.0, positions=[Position(market_id="x", side="YES", shares=500, cost_usd=300.0)])
    assert not risk.max_position("YES", forecast(0.80, "high"), QUOTE, busy).approved


def test_order_on_wrong_market_raises():
    order = OrderRequest(market_id="autre", side="YES", amount_usd=10)
    with pytest.raises(ValueError):
        risk.check(order, forecast(0.57), QUOTE, CASH_1000)
