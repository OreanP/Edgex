# EdgeX — agent de recherche probabiliste (paper trading)

> TODO — Une phrase : ce que fait EdgeX, pour qui, et pourquoi c'est utile.

🎥 Vidéo (2 min) : TODO

## Tester en 3 commandes
```bash
python -m venv .venv && source .venv/bin/activate   # Windows : .venv\Scripts\activate
pip install -r requirements.txt
EDGEX_MODE=offline streamlit run app.py              # mode démo : sans clé ni réseau (à brancher par C + D)
```
Mode live : copier `.env.example` en `.env`, y mettre `OPENAI_API_KEY`, puis `streamlit run app.py`.

## Comment ça marche
TODO — schéma : source de marchés → agent (recherche, estimation, contradicteur) → moteur de risque → paper broker → interface.

## Pourquoi c'est un agent
TODO — l'agent choisit ses recherches, révise son estimation après la phase contradictoire et décide YES / NO / SKIP ;
un moteur de risque déterministe borne ses actions.

## Cadre
- Paper trading uniquement : aucune transaction réelle, aucun wallet.
- Données de marché publiques, en lecture seule.
- Le mode démo rejoue un run réel enregistré le TODO.

## Fait pendant le hackathon (25–27/09/2026)
TODO — préciser toute réutilisation de code existant (obligatoire d'après le règlement).

## Équipe
TODO — noms des quatre membres.
