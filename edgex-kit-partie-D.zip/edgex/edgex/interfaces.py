"""Signatures que chaque partie doit respecter : le contrat entre A, B, C et D.

Chacun code CONTRE ces signatures, jamais contre le code interne des autres.
"""

from __future__ import annotations

from typing import Callable, Protocol

from .schemas import AgentStep, Forecast, Market, OrderRequest, Portfolio, Quote, RiskDecision, RunResult, Trade

StepCallback = Callable[[AgentStep], None]


class MarketSource(Protocol):
    """Partie B (Polymarket). FixtureMarketSource (fakes.py) la remplace pour les tests et la démo."""

    def list_markets(self, limit: int = 10) -> list[Market]: ...

    def get_market(self, market_id: str) -> Market: ...

    def get_quote(self, market_id: str) -> Quote: ...


class Broker(Protocol):
    """Partie B (paper broker). place_order DOIT appeler risk.check() avant d'exécuter quoi que ce soit."""

    def get_portfolio(self) -> Portfolio: ...

    def place_order(
        self, order: OrderRequest, forecast: Forecast, quote: Quote
    ) -> tuple[RiskDecision, Trade | None]: ...


class AgentRunner(Protocol):
    """Partie A. Appelle on_step à chaque action pour que l'interface (C) affiche la trace en direct."""

    def __call__(
        self,
        market_id: str,
        source: MarketSource,
        broker: Broker,
        on_step: StepCallback | None = None,
    ) -> RunResult: ...
