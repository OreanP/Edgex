"""Mode démo (partie D) : enregistrer un VRAI run réussi, puis le rejouer à l'identique.

La vidéo ne dépend alors d'aucune API externe. Dites-le honnêtement dans le README :
« le mode démo rejoue un run réel enregistré le JJ/MM ».
"""

from __future__ import annotations

import time
from pathlib import Path

from .interfaces import StepCallback
from .schemas import RunResult


def save_run(result: RunResult, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(result.model_dump_json(indent=2), encoding="utf-8")
    return path


def load_run(path: str | Path) -> RunResult:
    return RunResult.model_validate_json(Path(path).read_text(encoding="utf-8"))


def replay(result: RunResult, on_step: StepCallback, speed: float = 1.0, max_pause_s: float = 3.0) -> RunResult:
    """Réémet les étapes au rythme d'origine (accéléré par `speed`, pauses plafonnées)."""
    previous = None
    for step in result.steps:
        if previous is not None and speed > 0:
            gap = (step.timestamp - previous).total_seconds() / speed
            time.sleep(min(max(gap, 0.0), max_pause_s))
        on_step(step)
        previous = step.timestamp
    return result
