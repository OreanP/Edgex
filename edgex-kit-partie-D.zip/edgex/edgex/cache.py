"""Cache disque pour les appels HTTP de données de marché (partie D, utilisé par B).

Variable d'environnement EDGEX_MODE :
- live    : toujours le réseau (la réponse est quand même enregistrée) ;
- cached  : réutilise une réponse de moins de ttl_s secondes (défaut) ;
            si le réseau échoue, se rabat sur la dernière réponse connue ;
- offline : uniquement le cache, aucun appel réseau (tests, démo sans connexion).
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any

import requests


def _path_for(url: str, params: dict[str, Any] | None) -> Path:
    folder = Path(os.getenv("EDGEX_CACHE_DIR", ".cache"))
    raw = url + "?" + json.dumps(params or {}, sort_keys=True)
    return folder / (hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32] + ".json")


def get_json(url: str, params: dict[str, Any] | None = None, ttl_s: int = 300, timeout_s: float = 10.0) -> Any:
    mode = os.getenv("EDGEX_MODE", "cached")
    path = _path_for(url, params)
    if mode != "live" and path.exists():
        is_fresh = time.time() - path.stat().st_mtime < ttl_s
        if mode == "offline" or is_fresh:
            return json.loads(path.read_text(encoding="utf-8"))
    if mode == "offline":
        raise RuntimeError(f"Mode offline : aucune réponse en cache pour {url}")
    try:
        response = requests.get(url, params=params, timeout=timeout_s)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException:
        if path.exists():  # secours : dernière réponse connue
            return json.loads(path.read_text(encoding="utf-8"))
        raise
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data), encoding="utf-8")
    return data
