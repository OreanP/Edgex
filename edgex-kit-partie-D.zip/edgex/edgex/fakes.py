"""Faux composants pour travailler en parallèle et tester sans réseau (partie D).

- FixtureMarketSource : remplace la source Polymarket de B tant qu'elle n'est pas prête ;
- SimpleBroker        : broker fictif en mémoire (B livre le vrai : persistance, P&L) ;
- fake_agent          : agent scripté qui déroule le scénario de démo, pour que C
                        construise l'interface sans attendre A.

Générer un exemple de run pour l'interface : python -m edgex.fakes
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from . import risk
from .interfaces import Broker, MarketSource, StepCallback
from .schemas import (
    AgentStep,
    Evidence,
    Forecast,
    Market,
    OrderRequest,
    Portfolio,
    Position,
    Quote,
    RiskConfig,
    RiskDecision,
    RunResult,
    StepKind,
    Trade,
)

FIXTURES_DIR = Path(__file__).resolve().parent.parent / "fixtures"


class FixtureMarketSource:
    """Source de marchés lue dans fixtures/ (respecte l'interface MarketSource)."""

    def __init__(self, folder: Path = FIXTURES_DIR) -> None:
        markets = json.loads((folder / "markets.json").read_text(encoding="utf-8"))
        quotes = json.loads((folder / "quotes.json").read_text(encoding="utf-8"))
        self._markets = {m["id"]: Market.model_validate(m) for m in markets}
        self._quotes = {q["market_id"]: Quote.model_validate(q) for q in quotes}

    def list_markets(self, limit: int = 10) -> list[Market]:
        return list(self._markets.values())[:limit]

    def get_market(self, market_id: str) -> Market:
        return self._markets[market_id]

    def get_quote(self, market_id: str) -> Quote:
        return self._quotes[market_id]


class SimpleBroker:
    """Broker fictif en mémoire (respecte l'interface Broker)."""

    def __init__(self, cash_usd: float = 1000.0, cfg: RiskConfig | None = None) -> None:
        self._portfolio = Portfolio(cash_usd=cash_usd)
        self._cfg = cfg or RiskConfig()

    def get_portfolio(self) -> Portfolio:
        return self._portfolio.model_copy(deep=True)

    def place_order(
        self, order: OrderRequest, forecast: Forecast, quote: Quote
    ) -> tuple[RiskDecision, Trade | None]:
        decision = risk.check(order, forecast, quote, self._portfolio, self._cfg)
        if not decision.approved:
            return decision, None
        trade = Trade(
            market_id=order.market_id,
            side=order.side,
            amount_usd=order.amount_usd,
            price=decision.price,
            shares=round(order.amount_usd / decision.price, 4),
        )
        pf = self._portfolio
        pf.cash_usd = round(pf.cash_usd - trade.amount_usd, 2)
        pf.trades.append(trade)
        for pos in pf.positions:
            if pos.market_id == trade.market_id and pos.side == trade.side:
                pos.shares += trade.shares
                pos.cost_usd += trade.amount_usd
                break
        else:
            pf.positions.append(
                Position(market_id=trade.market_id, side=trade.side, shares=trade.shares, cost_usd=trade.amount_usd)
            )
        return decision, trade


def fake_agent(
    market_id: str,
    source: MarketSource,
    broker: Broker,
    on_step: StepCallback | None = None,
    delay_s: float = 0.0,
) -> RunResult:
    """Scénario scripté : recherche → estimation → contradicteur → risque → trade fictif."""
    steps: list[AgentStep] = []

    def emit(kind: StepKind, message: str, **data: Any) -> None:
        step = AgentStep(kind=kind, message=message, data=data)
        steps.append(step)
        if on_step:
            on_step(step)
        if delay_s:
            time.sleep(delay_s)

    market = source.get_market(market_id)
    quote = source.get_quote(market_id)
    emit("market", f"Marché lu : {market.question}", market_probability=round(quote.implied_probability, 3))
    emit("search", "Recherche de sources récentes (FAUX AGENT, données fictives)")
    initial = Forecast(
        probability=0.64,
        confidence="medium",
        evidence_for=[Evidence(title="Source A (fictive)", summary="Élément favorable.", stance="for")],
        rationale="Estimation initiale (fictive).",
    )
    emit("estimate", "Estimation initiale : 64 %", probability=initial.probability)
    emit("critic", "Recherche de preuves contradictoires")
    final = initial.model_copy(
        update={
            "probability": 0.57,
            "evidence_against": [Evidence(title="Source D (fictive)", summary="Élément défavorable.", stance="against")],
            "rationale": "Estimation révisée après la phase contradictoire (fictive).",
        }
    )
    emit("revise", "Estimation révisée : 57 %", probability=final.probability)

    order = OrderRequest(market_id=market_id, side="YES", amount_usd=120.0)
    decision, trade = broker.place_order(order, final, quote)
    emit("risk", decision.reasons[-1], approved=decision.approved, max_amount_usd=decision.max_amount_usd)
    if not decision.approved and decision.max_amount_usd > 0:
        order = OrderRequest(market_id=market_id, side="YES", amount_usd=decision.max_amount_usd)
        decision, trade = broker.place_order(order, final, quote)
        emit("risk", decision.reasons[-1], approved=decision.approved)

    if trade is None:
        emit("skip", f"Aucune position : {decision.reasons[-1]}")
    else:
        emit("trade", f"PAPER BUY YES : {trade.amount_usd:.2f} $ à {trade.price:.2f}", trade_id=trade.trade_id)
    return RunResult(
        market=market,
        quote=quote,
        initial_forecast=initial,
        final_forecast=final,
        decision="SKIP" if trade is None else "BUY_YES",
        skip_reason=decision.reasons[-1] if trade is None else None,
        requested_order=order,
        risk=decision,
        trade=trade,
        steps=steps,
    )


if __name__ == "__main__":
    from .replay import save_run

    src = FixtureMarketSource()
    result = fake_agent(src.list_markets()[0].id, src, SimpleBroker())
    print("Écrit :", save_run(result, Path("runs") / "exemple_fake_agent.json"))
